using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AddTimeLabel : MonoBehaviour
{
    [SerializeField] LevelSettings level;
    Text label;

    void Awake()
    {
        label = GetComponent<Text>();
        label.text = "+" + level.additiveTime;
    }
}
