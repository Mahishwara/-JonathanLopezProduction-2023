using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class AnswerChecker : MonoBehaviour
{
    public int CheckAnswers(ICheckable checkable)
    {
        for (int i = 0; i < checkable.ReturnUserAnswers().Length; i++)
            if (IsCorrectAnswer(i, checkable) > 0) return 1;
            else if (IsCorrectAnswer(i, checkable) < 0) return -1;
        return 0;
    }

    int IsCorrectAnswer(int answerIndex, ICheckable checkable)
    {
        var userAnswer = checkable.ReturnUserAnswers()[answerIndex];
        var answer = checkable.ReturnCorrectAnswers()[answerIndex];
        try
        {
            return double.Parse(userAnswer).CompareTo(double.Parse(answer));
        }
        catch
        {
            return userAnswer.CompareTo(answer);
        }
    }
}
