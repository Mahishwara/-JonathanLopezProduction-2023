using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioActivator : MonoBehaviour
{
    [SerializeField] string musicIndex;

    void Start()
    {
        AudioManager.instance.PlayMusic(musicIndex);
    }
}
