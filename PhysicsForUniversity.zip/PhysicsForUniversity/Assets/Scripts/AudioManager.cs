using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    [SerializeField] AudioConfig[] configs;
    Dictionary<string, AudioConfig> dictionary;
    AudioSource source;

    public static AudioManager instance = null;
    public static bool isMusic;
    public static bool isSounds;

    void Awake()
    {
        if (instance == null) instance = this;
        else Destroy(gameObject);

        DontDestroyOnLoad(gameObject);

        source = GetComponent<AudioSource>();

        Initialize();
    }

    void Initialize()
    {
        dictionary = new Dictionary<string, AudioConfig>();
        foreach (var config in configs) dictionary[config.index] = config;
        SaveSettings();
    }

    public static void SaveSettings()
    {
        isMusic = Convert.ToBoolean(PlayerPrefs.GetString("Music", "true"));
        isSounds = Convert.ToBoolean(PlayerPrefs.GetString("Sounds", "true"));
        PlayerPrefs.Save();
        ActivateSettings();
    }

    public static void ActivateSettings()
    {
        if (isMusic && !instance.source.isPlaying) instance.source.Play();
        else if (!isMusic) instance.source.Stop();
    }

    public void PlayMusic(string index)
    {
        if (source.clip == null || source.clip != dictionary[index].clip)
        {
            source.Stop();
            var clip = dictionary[index];
            source.volume = clip.volume;
            source.clip = clip.clip;
            if (isMusic)
            {
                if (!source.isPlaying) source.Play();
            }
        }
    }

    public void PlaySound(string index)
    {
        if (isSounds)
        {
            var sound = dictionary[index];
            source.PlayOneShot(sound.clip, sound.volume);
        }
    }
}
