using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class BackgroundConfig
{
    public Transform[] backgroundPaths;
    public Vector3 position;
    public bool isHorizontal;
    public BackgroundConfig nextBackground;
    public BackgroundConfig previousBackground;

    public void SetConnectedBackground(BackgroundConfig config)
    {
        nextBackground = config;
        config.previousBackground = this;
    }

    public void ChangePosition(float distance, bool isNext)
    {
        var connectedBackground = isNext ? nextBackground : previousBackground;
        if (!isHorizontal)
            position.x = GetNewCoordinate(position.x, connectedBackground.position.x, distance);
        else
            position.y = GetNewCoordinate(position.y, connectedBackground.position.y, distance);
        SetNewPositions();
    }

    void SetNewPositions()
    {
        foreach (var path in backgroundPaths)
        {
            if (!isHorizontal) SetNewPos(path, position.x, path.position.y);
            else SetNewPos(path, path.position.x, position.y);
        }
    }

    float GetNewCoordinate(float pos, float targetPos, float distance)
    {
        if (targetPos > pos) return targetPos + distance;
        return targetPos - distance;
    }

    Vector3 SetNewPos(Transform path, float x, float y) => path.position = new Vector3(x, y, path.position.z);
}
