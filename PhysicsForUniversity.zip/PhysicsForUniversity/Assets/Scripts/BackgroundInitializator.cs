using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundInitializator : MonoBehaviour
{
    [SerializeField] BackgroundConfig[] backgroundConfigs;

    void Awake()
    {
        bool isStart = true;
        BackgroundConfig startConfig = new BackgroundConfig();
        for (int i = 0; i < backgroundConfigs.Length; i++)
        {
            if (isStart)
            {
                startConfig = backgroundConfigs[i];
                isStart = false;
            }
            if (i + 1 < backgroundConfigs.Length && backgroundConfigs[i + 1].isHorizontal == backgroundConfigs[i].isHorizontal)
                backgroundConfigs[i + 1].SetConnectedBackground(backgroundConfigs[i]);
            else
            {
                isStart = true;
                startConfig.SetConnectedBackground(backgroundConfigs[i]);
            }
        }
    }

    public BackgroundConfig GetBackgroundPath(int index) => backgroundConfigs[index];
}
