using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundMovement : MonoBehaviour
{
    [SerializeField] Transform cameraPos;
    [SerializeField] Vector2 moveDistance; 
    BackgroundInitializator initializator;
    BackgroundConfig leftBg, downBg;

    void Awake()
    {
        initializator = GetComponent<BackgroundInitializator>();
        leftBg = initializator.GetBackgroundPath(0);
        downBg = initializator.GetBackgroundPath(3);
    }

    void Update()
    {
        TryMove(cameraPos.position.x, moveDistance.x, ref leftBg);
        TryMove(cameraPos.position.y, moveDistance.y, ref downBg);
    }

    void MoveBackground(BackgroundConfig background,bool isNext, float distance)
    {
        if (!isNext) background = background.nextBackground;
        background.ChangePosition(distance, isNext);
    }

    void TryMove(float cameraCoordinate, float distance, ref BackgroundConfig background)
    {
        var nextBgPos = background.isHorizontal ? background.nextBackground.position.y : background.nextBackground.position.x;
        var previousBgPos = background.isHorizontal ? background.position.y : background.position.x;

        if (cameraCoordinate > nextBgPos - distance)
        {
            MoveBackground(background, true, distance * 2);
            background = background.previousBackground;
        }
        else if (cameraCoordinate < previousBgPos + distance)
        {
            MoveBackground(background, false, distance * 2);
            background = background.nextBackground;
        }
    }
}
