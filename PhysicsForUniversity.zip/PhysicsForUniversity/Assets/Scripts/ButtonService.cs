using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonService : MonoBehaviour
{
    ButtonSystem system;

    void Start()
    {
        system = GameObject.Find("Canvas").GetComponent<ButtonSystem>();    
    }

    public void OnClick(GameObject task)
    {
        system.CheckAnswer(task);
    }
}
