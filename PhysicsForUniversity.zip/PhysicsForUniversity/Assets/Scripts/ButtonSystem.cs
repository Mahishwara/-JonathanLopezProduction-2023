using System;
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ButtonSystem : MonoBehaviour
{
    [SerializeField] TaskService taskService;
    [SerializeField] UIElementsActivator UIElementsActivator;
    [SerializeField] LevelSettings level;
    [SerializeField] TaskSpawner spawner;
    [SerializeField] HintActivator hintActivator;
    [SerializeField] public bool isHintAvailable;
    [SerializeField] Timer timer;

    public void Restart() 
    {
        AudioManager.instance.PlaySound("Click");
        SceneManager.LoadScene(level.index);
    }

    public void Menu()
    {
        AudioManager.instance.PlaySound("Click");
        SceneManager.LoadScene(0);
    }

    public void Next()
    {
        AudioManager.instance.PlaySound("Click");
        SceneManager.LoadScene(level.index + 1);
    }

    public void OpenOrCloseHintWindow()
    {
        AudioManager.instance.PlaySound("Click");
        if (!level.HintIsUsed) UIElementsActivator.ActivateDeactivateElement(UIElementType.WarningWindow);
        level.HintIsUsed = true;
        hintActivator.ActivateHint();
        UIElementsActivator.ActivateDeactivateElement(UIElementType.HintWindow);
    }

    public void OpenOrCloseDeviceWindow()
    {
        AudioManager.instance.PlaySound("Terminal");
        spawner.SpawnTask();
        UIElementsActivator.ActivateDeactivateElement(UIElementType.DeviceWindow);
    }

    public void OpenOrCloseHintWithWarningWindow()
    {
        AudioManager.instance.PlaySound("Click");
        if (!isHintAvailable) UIElementsActivator.ActivateDeactivateElement(UIElementType.ErrorWindow);
        else if (!level.HintIsUsed) UIElementsActivator.ActivateDeactivateElement(UIElementType.WarningWindow);
        else OpenOrCloseHintWindow();
    }

    public void OpenOrCloseTheoryWindow()
    {
        AudioManager.instance.PlaySound("Click");
        UIElementsActivator.ActivateDeactivateElement(UIElementType.TheoryWindow);
        timer.StopStartTimer();
    }

    public void OpenOrClosePauseWindow()
    {
        AudioManager.instance.PlaySound("Click");
        UIElementsActivator.ActivateDeactivateElement(UIElementType.PauseWindow);
        timer.StopStartTimer();
    }

    public void CheckAnswer(GameObject task)
    {
        AudioManager.instance.PlaySound("Terminal");
        taskService.MakeActionForAnswer(task);
    }
}
