using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Checkpoint : MonoBehaviour
{
    [SerializeField] public int index;
    [SerializeField] CheckpointSystem system;
    [SerializeField] public bool isActive;

    public void SetUnsetCheckpoint(int index) => isActive = index == this.index;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player") system.ChangeCheckpoint(index);
    }
}
