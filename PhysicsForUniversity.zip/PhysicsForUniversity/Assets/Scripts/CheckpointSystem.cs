using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckpointSystem : MonoBehaviour
{
    [SerializeField] Checkpoint[] checkpoints;
    Transform player;
    Vector3 checkpointPos;
    Checkpoint currentCheckpoint;

    void Awake()
    {
        checkpoints = GetComponentsInChildren<Checkpoint>();
        player = GameObject.FindGameObjectWithTag("Player").transform;
        currentCheckpoint = checkpoints[0];
        checkpointPos = currentCheckpoint.transform.position;
    }

    public void ChangeCheckpoint(int newIndex)
    {
        if (currentCheckpoint.index < newIndex)
        {
            currentCheckpoint.SetUnsetCheckpoint(newIndex);
            currentCheckpoint = checkpoints[newIndex];
            currentCheckpoint.SetUnsetCheckpoint(newIndex);
            checkpointPos = currentCheckpoint.transform.position;
        }
    }

    public void ReturnOnCheckpoint()
    {
        player.position = checkpointPos;
    }
}
