using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChoosingAnswer : MonoBehaviour
{
    string value;
    Text text;

    void Awake()
    {
        text = GetComponentInChildren<Text>();     
    }

    public void SetValue(string value)
    {
        this.value = value;
        if (text) text.text = value;
    }

    public string GetValue() => value;
}
