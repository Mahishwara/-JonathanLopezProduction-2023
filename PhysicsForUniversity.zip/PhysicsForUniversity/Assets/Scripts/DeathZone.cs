using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathZone : MonoBehaviour
{
    [SerializeField] Timer timer;
    [SerializeField] CheckpointSystem checkpointSystem;

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            timer.AddTime();
            RespawnPlayer();
        }
    }

    void RespawnPlayer() => checkpointSystem.ReturnOnCheckpoint();
}
