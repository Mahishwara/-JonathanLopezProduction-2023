using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeviceWindowMover : MonoBehaviour
{
    RectTransform rectTransform;

    void Start() =>
        rectTransform = GetComponent<RectTransform>();

    public void MoveWindow(bool isCancel)
    {
        if (!isCancel) rectTransform.localPosition = new Vector3(0, 0 + Screen.height / 4, 0);
        else rectTransform.localPosition = Vector3.zero;
    }
}
