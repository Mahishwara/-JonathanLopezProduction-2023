using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DialogCloud : MonoBehaviour
{
    Text text;
    Transform point;

    void Awake() =>
        text = GetComponentInChildren<Text>();

    public void SetDialog(string index) =>
        text.text = DialogManager.instance.GetDialog(index);

    public void SetPoint(Transform dialogPoint) =>
        point = dialogPoint;

    void Update()
    {
        if (point) transform.position = point.position;    
    }
}
