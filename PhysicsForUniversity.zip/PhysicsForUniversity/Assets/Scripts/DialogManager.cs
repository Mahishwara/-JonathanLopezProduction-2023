using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DialogManager : MonoBehaviour
{
    [SerializeField] public DialogConfig[] dialogs;
    Dictionary<string, string> dialogsDictionary;

    public static DialogManager instance = null;

    void Awake()
    {
        if (instance == null) instance = this;
        else Destroy(gameObject);

        DontDestroyOnLoad(gameObject);

        dialogsDictionary = new Dictionary<string, string>();
        foreach (var dialog in dialogs) dialogsDictionary[dialog.index] = dialog.dialog;
    }

    public string GetDialog(string index) => dialogsDictionary[index];
}
