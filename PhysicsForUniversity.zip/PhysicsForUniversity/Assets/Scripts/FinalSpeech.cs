using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FinalSpeech : MonoBehaviour
{
    [SerializeField] Player player;

    public void StartFinalSpeech(float time)
    {
        StartCoroutine(Speak(time));
    }

    IEnumerator Speak(float time)
    {
        player.ActivateDialog("Final1");
        yield return new WaitForSeconds(time/3);
        player.ActivateDialog("Final2");
        yield return new WaitForSeconds(time/3);
        player.ActivateDialog("Final3");
    }
}
