using UnityEngine;

public class Finish : MonoBehaviour
{
    [SerializeField] ResultSystem results;
    [SerializeField] LevelSettings level;
    [SerializeField] UIElementsActivator service;
    [SerializeField] Timer timer;
    FinalSpeech finalSpeech;
    float timeForFinalSpeech = 6f;

    private void Awake() =>
        finalSpeech = GetComponent<FinalSpeech>();    

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            level.LevelCompleted = true;
            timer.StopStartTimer();
            LevelManager.instance.UnlockNextLevel();
            if (LevelManager.instance.AllLevelsCompleted())
            {
                finalSpeech.StartFinalSpeech(timeForFinalSpeech);
                Invoke(nameof(ActivateWinWindow), timeForFinalSpeech);
            }
            else ActivateWinWindow();
        }
    }

    void ActivateWinWindow()
    {
        AudioManager.instance.PlaySound("Win");
        timer.gameObject.SetActive(false);
        service.ActivateDeactivateElement(UIElementType.WinWindow);
        results.ShowResults();
    }    
}
