using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hint : MonoBehaviour
{
    [SerializeField] public int index;
    [SerializeField] public GameObject hintObject;

    void Awake()
    {
        hintObject = gameObject;    
    }
}
