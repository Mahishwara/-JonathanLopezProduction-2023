using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements.Experimental;

public class HintActivator : MonoBehaviour
{
    [SerializeField] TaskingConnectionsService taskingService;
    Hint hint;

    public void ActivateHint()
    {
        if (hint) hint.hintObject.SetActive(false);
        hint = taskingService.GetTasking(true).hint;
        if (hint != null) hint.hintObject.SetActive(true);
    }
}
