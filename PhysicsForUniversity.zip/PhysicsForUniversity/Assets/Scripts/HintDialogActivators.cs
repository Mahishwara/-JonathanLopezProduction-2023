using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HintDialogActivators : MonoBehaviour
{
    void Awake()
    {
        var isActivateHintDialog = Convert.ToBoolean(PlayerPrefs.GetString("FirstPlaying", "true"));
        if (!isActivateHintDialog) gameObject.SetActive(false);
        PlayerPrefs.SetString("FirstPlaying", false.ToString());
    }
}
