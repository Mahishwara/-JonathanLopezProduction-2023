using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IAnswerable
{
    void CalculateAnswers();
    Action MakeActionForAnswer(int comparableValue);

}
