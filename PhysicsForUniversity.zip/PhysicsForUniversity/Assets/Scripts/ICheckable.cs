using System;

public interface ICheckable
{
    string[] ReturnCorrectAnswers();
    string[] ReturnUserAnswers();
}
