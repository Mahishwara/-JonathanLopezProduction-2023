using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class InputFieldWithKeyboard : InputField
{
    DeviceWindowMover mover;

    protected override void Start() => 
        mover = GameObject.Find("Canvas/Windows/DeviceWindow").GetComponent<DeviceWindowMover>();

    public override void OnPointerClick(PointerEventData eventData)
    {
        base.OnPointerClick(eventData);
        TouchScreenKeyboard.hideInput = true;
        mover.MoveWindow(false);
    }

    public void CancelEdit() =>
        StartCoroutine(WaitForCloseKeyboard());

    IEnumerator WaitForCloseKeyboard()
    {
        yield return new WaitForSeconds(0.001f);
        if (!TouchScreenKeyboard.visible) mover.MoveWindow(true);
    }
}
