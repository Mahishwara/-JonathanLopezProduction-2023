using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Joystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
{
    Image joystick;
    Image joystickAll;
    Vector2 vector;

    void Start()
    {
        joystickAll = GetComponent<Image>();
        joystick = transform.GetChild(0).GetComponent<Image>();
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        OnDrag(eventData);
    }

    public void OnDrag(PointerEventData eventData)
    {
        Vector2 pos;

        if (RectTransformUtility.ScreenPointToLocalPointInRectangle(joystickAll.rectTransform, eventData.position, eventData.pressEventCamera, out pos))
        {
            pos.x = (pos.x / joystickAll.rectTransform.sizeDelta.x);
            pos.y = (pos.y / joystickAll.rectTransform.sizeDelta.y);
        }

        vector = new Vector2(pos.x, pos.y);
        vector = (vector.magnitude > 1.0f) ? vector.normalized : vector;

        joystick.rectTransform.anchoredPosition = new Vector2(vector.x * (joystickAll.rectTransform.sizeDelta.x / 2), vector.y * (joystickAll.rectTransform.sizeDelta.y / 2));

    }

    public void OnPointerUp(PointerEventData eventData)
    {
        vector = Vector2.zero;
        joystick.rectTransform.anchoredPosition = Vector2.zero;
    }

    public float Horizontal()
    {
        if (vector.x != 0)
            return vector.x;
        return Input.GetAxis("Horizontal");
    }
}
