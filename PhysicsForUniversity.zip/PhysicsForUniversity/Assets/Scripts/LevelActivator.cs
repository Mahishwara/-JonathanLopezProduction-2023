using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelActivator : MonoBehaviour
{
    public void ActivateLevel(int index) =>
        SceneManager.LoadScene(index);
}
