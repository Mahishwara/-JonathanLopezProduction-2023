using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelButton : MonoBehaviour
{
    [SerializeField] GameObject unlockedState, lockedState;
    
    public void SetUnlockedState()
    {
        lockedState.SetActive(false);
        unlockedState.SetActive(true);
    }
}
