using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class LevelButtonConfig
{
    public int index;
    public LevelButton button;

    public void ActivateButton() => button.SetUnlockedState();
}
