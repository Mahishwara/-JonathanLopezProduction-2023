using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class LevelInfo : MonoBehaviour
{
    [SerializeField] Text title, information;
    [SerializeField] StarsActivator starsActivator;
    LevelActivator levelActivator;
    int index;

    void Awake() =>
        levelActivator = GameObject.Find("Canvas/LevelActivator").GetComponent<LevelActivator>();    

    public void SetLevelInfo(LevelInfoParts level)
    {
        title.text = level.title;
        information.text = level.info;
        index = level.index;
        var starsCount = level.stars;
        starsActivator.ActivateStars(starsCount);
    }

    public void DestroyLevelInfo() => Destroy(gameObject);

    public void ActivateLevel() => levelActivator.ActivateLevel(index);
}
