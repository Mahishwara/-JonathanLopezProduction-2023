using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelInfoActivator : MonoBehaviour
{
    [SerializeField] LevelInfoParts[] levels;
    [SerializeField] GameObject levelPrefab;
    Dictionary<int, LevelInfoParts> dictionary;

    void Awake()
    {
        dictionary = new Dictionary<int, LevelInfoParts>();
        foreach (var level in levels)
        {
            var levelState = LevelManager.instance.GetLevelState(level.index);
            level.SetStars(levelState.completeStars);
            dictionary[level.index] = level;
        }
    }

    public void ActivateLevelInfo(int index)
    {
        var levelInfo = Instantiate(levelPrefab, transform.parent);
        levelInfo.GetComponent<LevelInfo>().SetLevelInfo(dictionary[index]);
    }
}
