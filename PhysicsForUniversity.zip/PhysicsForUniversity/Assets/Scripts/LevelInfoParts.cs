using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class LevelInfoParts
{
    public int index;
    public string title;
    public string info;
    public int stars;

    public void SetStars(int stars) => this.stars = stars;
}
