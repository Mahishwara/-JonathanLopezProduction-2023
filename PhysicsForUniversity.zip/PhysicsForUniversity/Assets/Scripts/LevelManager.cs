using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelManager : MonoBehaviour
{
    [SerializeField] LevelState[] levels;
    Dictionary<(int, int), LevelState> dictionary;
    Dictionary<int, (int themeIndex, int levelIndex)> indexDictionary;
    Dictionary<int, string> PlayerPrefsDicitionary;
    int[] maxCountLevelsInTheme = new int[3] {2, 2, 1};
    int[] themeLevelsUnlockedCount;
    int themeCount = 3;

    public static LevelManager instance = null;

    private void Awake()
    {
        if (instance == null) instance = this;
        else Destroy(gameObject);

        DontDestroyOnLoad(gameObject);

        InitializeIndexDictionary();
        InitializeThemeIndexDictionary();
        InitializeLevelsDictionary();
        SetLevelsState();
    }

    void InitializeLevelsDictionary()
    {
        dictionary = new Dictionary<(int, int), LevelState>();
        foreach (var level in levels)
        {
            level.SetStars();
            dictionary[(level.levelTheme, level.levelIndex)] = level;
        }
    }

    void InitializeThemeIndexDictionary()
    {
        PlayerPrefsDicitionary = new Dictionary<int, string>();
        PlayerPrefsDicitionary[0] = "FirstThemeLevelsUnlocked";
        PlayerPrefsDicitionary[1] = "SecondThemeLevelsUnlocked";
        PlayerPrefsDicitionary[2] = "ThirdThemeLevelsUnlocked";
    }

    void InitializeIndexDictionary()
    {
        indexDictionary = new Dictionary<int, (int themeIndex, int levelIndex)>();
        int themeIndex = 0;
        int levelIndex = 0;
        for (int i = 0; i < levels.Length; i++)
        {
            indexDictionary[i + 1] = (themeIndex, levelIndex);
            if (++levelIndex == maxCountLevelsInTheme[themeIndex])
            {
                levelIndex = 0;
                themeIndex++;
            }
        }
    }

    void InitializeUnlockedCountsArray()
    {
        themeLevelsUnlockedCount = new int[themeCount];
        for (int i = 0; i < themeCount; i++)
        {
            var index = GetPlayerPrefsIndex(i);
            themeLevelsUnlockedCount[i] = PlayerPrefs.GetInt(index, 1);
        }
    }

    public string GetPlayerPrefsIndex(int index) => PlayerPrefsDicitionary[index];

    public void UnlockNextLevel()
    {
        var index = ChangeLevelIndex(SceneManager.GetActiveScene().buildIndex);
        if (index.levelIndex < maxCountLevelsInTheme[index.themeIndex] - 1)
        {
            PlayerPrefs.SetInt(GetPlayerPrefsIndex(index.themeIndex), index.levelIndex + 2);
            SetLevelsState();
        }
    }

    void SetLevelsState()
    {
        InitializeUnlockedCountsArray();
        for (int i = 0; i < themeCount; i++)
            for (int j = 0; j < themeLevelsUnlockedCount[i]; j++)
                dictionary[(i,j)].isActivate = true;
    }

    public LevelState GetLevelState(int index)
    {
        var correctIndex = ChangeLevelIndex(index);
        return dictionary[correctIndex];
    }

    (int themeIndex, int levelIndex) ChangeLevelIndex(int index) => indexDictionary[index];

    public void SetCompletedStars(int levelIndex, int stars)
    {
        var index = ChangeLevelIndex(levelIndex);
        var level = dictionary[index];
        if (level.completeStars < stars)  
            PlayerPrefs.SetInt(level.levelTheme + "." + level.levelIndex + " stars", stars);
        level.SetStars();
    }

    public LevelState[] GetThemeLevelStates(int themeIndex)
    {
        var levels = new LevelState[maxCountLevelsInTheme[themeIndex]];
        for (int i = 0; i < levels.Length; i++)
            levels[i] = dictionary[(themeIndex, i)];
        return levels;
    }

    public bool AllLevelsCompleted()
    {
        foreach (var level in levels)
        {
            if (level.completeStars == 0) return false;
        }
        return true;
    }
}
