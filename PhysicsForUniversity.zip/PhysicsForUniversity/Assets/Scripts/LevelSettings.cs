using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelSettings : MonoBehaviour
{
    [SerializeField] public int requiredTime;
    [SerializeField] public int index;
    [SerializeField] public int additiveTime;

    public bool HintIsUsed { get; set; }
    public bool LevelCompleted { get; set; }

    void Start()
    {
        Time.timeScale = 1;
        index = SceneManager.GetActiveScene().buildIndex;
    }

    public int ReturnRequiredTime() => requiredTime;

    public int ReturnLevelIndex() => index;
}
