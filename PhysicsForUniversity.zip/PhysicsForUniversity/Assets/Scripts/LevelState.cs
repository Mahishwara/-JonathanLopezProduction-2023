using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class LevelState
{
    public int levelTheme;
    public int levelIndex;
    public bool isActivate;
    public int completeStars;

    public void SetStars() =>
        completeStars = PlayerPrefs.GetInt(levelTheme + "." +  levelIndex + " stars", 0);
}
