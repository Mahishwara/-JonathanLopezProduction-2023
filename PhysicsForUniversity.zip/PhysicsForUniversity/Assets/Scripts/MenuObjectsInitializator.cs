using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuObjectsInitializator : MonoBehaviour
{
    [SerializeField] LevelButtonConfig[] levelButtons;
    [SerializeField] StarsActivatorConfig[] starsActivators;
    [SerializeField] ProgressBarConfig[] progressBars;

    void Start()
    {
        InitializeLevelButtons();
        InitializeLevelStars();
        InitializeProgressBars();
    }

    void InitializeLevelButtons()
    {
        foreach (var levelButton in levelButtons)
        {
            var levelState = LevelManager.instance.GetLevelState(levelButton.index);
            if (levelState.isActivate) levelButton.ActivateButton();
        }
    }

    void InitializeLevelStars()
    {
        foreach (var starActivator in starsActivators)
        {
            var levelState = LevelManager.instance.GetLevelState(starActivator.index);
            var starsCount = levelState.completeStars;
            if (starsCount > 0) starActivator.activator.ActivateStars(starsCount);
        }
    }

    void InitializeProgressBars()
    {
        var sum = 0;
        for (int i = 0; i < progressBars.Length - 1; i++)
        {
            var starsCount = 0;
            var levelStates = LevelManager.instance.GetThemeLevelStates(i);
            foreach (var levelState in levelStates)
            {
                starsCount += levelState.completeStars;
                sum += levelState.completeStars;
            }
            FillSlider(starsCount, i);
        }
        FillSlider(sum, 3);
    }

    void FillSlider(int starsCount, int index)
    {
        var value = CalculateBarValue(starsCount, progressBars[index].maxValue);
        progressBars[index].progressBar.SetSlider(value);
    }

    float CalculateBarValue(float starsCount, float maxStarsCount) => 100 / maxStarsCount * starsCount;
}
