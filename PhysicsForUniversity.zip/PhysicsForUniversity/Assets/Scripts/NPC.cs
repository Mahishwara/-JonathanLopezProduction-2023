using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using UnityEngine;

public class NPC : MonoBehaviour, ITalkable
{
    [SerializeField] public int index;
    Transform dialogPoint;
    UIElementsActivator UIElementsActivator;

    private void Awake()
    {
        dialogPoint = transform.GetChild(0);
    }

    private void Start()
    {
        UIElementsActivator = GameObject.Find("UIElementsService").GetComponent<UIElementsActivator>();
    }

    public void ActivateDialog(string dialogIndex)
    {
        UIElementsActivator.ActivateDeactivateElement(UIElementType.DialogCloud, dialogPoint, dialogIndex);
    }
}
