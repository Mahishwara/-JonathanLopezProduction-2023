using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour, ITalkable
{
    Transform dialogPoint;
    UIElementsActivator UIElementsActivator;

    private void Awake()
    {
        dialogPoint = transform.GetChild(1);
    }

    private void Start()
    {
        UIElementsActivator = GameObject.Find("UIElementsService").GetComponent<UIElementsActivator>();
    }

    public void ActivateDialog(string dialogIndex)
    {
        UIElementsActivator.ActivateDeactivateElement(UIElementType.DialogCloud, dialogPoint, dialogIndex);
    }
}
