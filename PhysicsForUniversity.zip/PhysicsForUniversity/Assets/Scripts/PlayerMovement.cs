using System.Collections;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    Rigidbody2D rb;
    [SerializeField] float speed, jumpForce;
    float jumpValue = 0;
    Vector2 direction;
    [SerializeField] Joystick joystick;
    int countCollisions;
    bool isAutomaticMove;
    Transform target;
    Animator animator;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
    }
    
    void FixedUpdate()
    {
        if (!isAutomaticMove)
        {
            direction = new Vector2(joystick.Horizontal(), jumpValue * jumpForce);
            rb.velocity = direction * speed;
            if (direction.normalized.x < 0 && transform.localScale.x > 0 || direction.normalized.x > 0 && transform.localScale.x < 0)
                Flip();
            if (direction.magnitude != 0) animator.SetBool("Run", true);
            else animator.SetBool("Run", false);
        }
    }

    void Update()
    {
        if (isAutomaticMove)
        {
            if (transform.position != target.position) MoveToTarget();
            else animator.SetBool("Run", false);
        }

    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.tag == "Ground") countCollisions++;
        animator.SetBool("Jump", false);
    }

    void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.collider.tag == "Ground") countCollisions--;
        if (countCollisions == 0 && !isAutomaticMove) animator.SetBool("Jump", true);
    }

    public void Jump()
    {
        if (countCollisions > 0)
        {
            ChangeJumpValue();
            Invoke("ChangeJumpValue", 0.1f);
        }
    }

    void ChangeJumpValue()
    {
        jumpValue = jumpValue == 0 ? 1 : 0;
        animator.SetBool("Jump", true);
    }

    public void StartMoveToTarget(Transform target, float time)
    {
        this.target = target;
        animator.SetBool("Run", true);
        StartCoroutine(AutomaticMove(time));
    }

    IEnumerator AutomaticMove(float time)
    {
        rb.isKinematic = true;
        isAutomaticMove = true;
        direction = Vector2.zero;
        rb.velocity = Vector2.zero;
        if (target.position.x < transform.position.x && transform.localScale.x > 0 || target.position.x > transform.position.x && transform.localScale.x < 0)
            Flip();
        yield return new WaitForSeconds(time);
        isAutomaticMove = false;
        rb.isKinematic = false;
    }

    void MoveToTarget() =>
        transform.position = Vector3.MoveTowards(transform.position, target.position, speed * Time.deltaTime);

    void Flip()
    {
        transform.localScale = new Vector2 (-1 * transform.localScale.x, transform.localScale.y); 
    }
}
