using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Randomizer
{
    public static string RandomizeValue(List<string> usedValues, int mainValue)
    {
        while (true)
        {
            var value = Random.Range(mainValue - mainValue / 2, mainValue + mainValue / 2).ToString();
            if (!usedValues.Contains(value)) return value;
        }
    }
}
