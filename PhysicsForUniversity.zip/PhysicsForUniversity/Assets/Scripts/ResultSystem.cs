using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ResultSystem : MonoBehaviour
{
    [SerializeField] StarsActivator starsActivator;
    [SerializeField] Timer timer;
    [SerializeField] GameObject winWindow;
    [SerializeField] LevelSettings settings;
    int starsCount = 0;

    public void ShowResults()
    {
        var window = winWindow;
        ShowStars();
        ShowTime(window);
    }

    void ShowStars()
    {
        if (settings.LevelCompleted)
        {
            starsCount++;
            if (!settings.HintIsUsed)
            {
                starsCount++;
                if (timer.ReturnTime() <= settings.requiredTime) starsCount++;
            }
            starsActivator.ActivateStars(starsCount);
            LevelManager.instance.SetCompletedStars(settings.index, starsCount);
        }
    }

    void ShowTime(GameObject window) =>
        window.transform.GetChild(3).GetComponent<Text>().text = "��� �����: " + timer.ReturnTime();
}
