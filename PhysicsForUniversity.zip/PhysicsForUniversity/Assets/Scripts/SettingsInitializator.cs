using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SettingsInitializator : MonoBehaviour
{
    [SerializeField] Toggle musicToggle, soundsToggle;

    void Awake()
    {
        musicToggle.isOn = Convert.ToBoolean(PlayerPrefs.GetString("Music", "true"));
        soundsToggle.isOn = Convert.ToBoolean(PlayerPrefs.GetString("Sounds", "true"));
    }

    public void ChangeSettings(string index)
    {
        if (index == "Music") PlayerPrefs.SetString(index, musicToggle.isOn.ToString());
        else PlayerPrefs.SetString(index, soundsToggle.isOn.ToString());
        AudioManager.SaveSettings();
    }
}
