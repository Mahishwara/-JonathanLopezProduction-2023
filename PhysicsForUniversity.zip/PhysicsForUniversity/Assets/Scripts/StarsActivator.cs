using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class StarsActivator : MonoBehaviour
{
    [SerializeField] Image[] stars;

    void Awake() =>
        stars = GetComponentsInChildren<Image>();

    public void ActivateStars(int starsCount)
    {
        for (int i = 0; i < starsCount; i++) ActivateStar(stars[i]);
    }

    void ActivateStar(Image star) => star.color = Color.yellow;

}
