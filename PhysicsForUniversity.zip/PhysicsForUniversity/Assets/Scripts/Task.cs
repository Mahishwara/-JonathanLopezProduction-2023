using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public abstract class Task : MonoBehaviour, ICheckable, IAnswerable
{
    [Header("TaskSettings")]
    [SerializeField] TaskType type;
    [SerializeField] public int index;
    [SerializeField] Text conditionText;
    [SerializeField] public string condition;
    [Header("GenerateData")] 
    [SerializeField] public List<TaskData> initialData;
    [SerializeField] public string[] answers;

    public TaskingConnectionsService taskingService;
    public WayActivator wayActivator;

    public virtual void Start()
    {
        taskingService = GameObject.Find("TaskingConnectionService").GetComponent<TaskingConnectionsService>();
        wayActivator = GameObject.Find("WayService").GetComponent<WayActivator>();
        initialData = TaskDataGenerator.GenerateData(initialData);
        answers = new string[2];
    }

    public virtual void CreateCondition()
    {
        condition = $"��� ���� � ������ h1 =�{initialData[0].Value}��, �������� �� ���� � ��� ������ �� ������h2 = {initialData[1].Value}��. ���� ����� �����S � ������ ������������r ����?";
        SetCondition();
    }

    public void SetCondition() => conditionText.text = condition;

    public string[] ReturnCorrectAnswers() => answers;

    public virtual string[] ReturnUserAnswers()
    {
        var result = new string[2];
        return result;
    }

    public virtual void CalculateAnswers()
    {
        answers[0] = (initialData[0].Value + initialData[1].Value).ToString();
        answers[1] = (initialData[0].Value - initialData[1].Value).ToString();
    }

    public virtual Action MakeActionForAnswer(int comparableValue)
    {
        var npc = taskingService.GetTasking(true).npc;
        var index = "Fail1";
        if (comparableValue == 0) index = "Solve1";

        return () =>
        {
            npc.ActivateDialog(index);
            wayActivator.ActivateWay(index);
        };
    }
}
