using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Task1 : TaskOnInput
{
    public override void Start()
    {
        base.Start();
        answers = new string[inputFields.Length];
        CalculateAnswers();
        CreateCondition();
    }

    public override void CalculateAnswers() => base.CalculateAnswers();

    public override Action MakeActionForAnswer(int comparableValue) => base.MakeActionForAnswer(comparableValue);

    public override void CreateCondition() => base.CreateCondition();
}
