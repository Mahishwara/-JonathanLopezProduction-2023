﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Task23 : TaskOnInput
{
    public override void Start()
    {
        base.Start();
        answers = new string[inputFields.Length];
        CalculateAnswers();
        CreateCondition();
    }

    public override void CalculateAnswers()
    {
        double answer = initialData[1].Value * initialData[0].Value / 10;
        answer = Math.Round(answer, 1, MidpointRounding.AwayFromZero);
        answers[0] = answer.ToString();
    }

    public override Action MakeActionForAnswer(int comparableValue)
    {
        if (comparableValue == 0) return () => wayActivator.ActivateWay("Solve23");
        return () => { };
    }

    public override void CreateCondition()
    {
        condition = $"К вертикальной стене прижали кирпич. Модуль прижимающей горизонтальной силы F = {initialData[0].Value} Н. Определите максимальную массу кирпича, при которой он ещё не будет скользить по стене вниз. Коэффициент трения кирпича о стену μ = {initialData[1].Value}. (округлить до десятых, g = 10)";
        SetCondition();
    }
}
