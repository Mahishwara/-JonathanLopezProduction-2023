﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Task24 : TaskOnInput
{
    public override void Start()
    {
        base.Start();
        answers = new string[inputFields.Length];
        CalculateAnswers();
        CreateCondition();
    }

    public override void CalculateAnswers()
    {
        double answer = initialData[1].Value * initialData[0].Value;
        answers[0] = answer.ToString();

        var movementType = "равнозамедленное";
        if (answer > 0) movementType = "равноускоренное";
        else if (answer == 0) movementType = "равномерное";
        answers[1] = movementType; 
    }

    public override Action MakeActionForAnswer(int comparableValue)
    {
        if (comparableValue == 0) return () => wayActivator.ActivateWay("Solve24");
        return () => { };
    }

    public override void CreateCondition()
    {
        condition = $"Кабина лифта общей массой m = {initialData[0].Value} кг поднимается на тросе, сила упругости которого F = {initialData[1].Value} кН. Определите равнодействующую сил, приложенных к кабине лифта. Изобразите эти силы. Является ли движение лифта равномерным?";
        SetCondition();
    }
}
