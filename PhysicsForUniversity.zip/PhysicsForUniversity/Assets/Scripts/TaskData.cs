﻿using System;
using UnityEngine;
using Random = UnityEngine.Random;

[Serializable]
public class TaskData
{
    public float Value;
    public float startRange, endRange;
    [SerializeField] bool isDouble;

    public TaskData(float value)
    {
        Value = value;
    }

    public void RandomizeValue()
    {
        Value = Random.Range(startRange, endRange);
        if (isDouble) Value = (float)Math.Round(Value, 1);
        else Value = (float)Math.Round(Value, 0);
    }
}
