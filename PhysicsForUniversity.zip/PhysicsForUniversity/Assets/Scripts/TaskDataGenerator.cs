﻿using System;
using System.Collections.Generic;

public static class TaskDataGenerator
{
    public static List<TaskData> GenerateData(List<TaskData> tasks)
    {
        for (int i = 0; i < tasks.Count; i++)
            tasks[i].RandomizeValue();
        return tasks;
    }
}
