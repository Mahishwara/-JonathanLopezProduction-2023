using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TaskOnChoosing : Task
{
    [SerializeField] public List<ChoosingAnswer> choosingAnswers;
    List<ChoosingAnswer> remainChoosingAnswers;
    string userAnswer = "0";

    void Awake() => answers = new string[1];

    public override string[] ReturnUserAnswers()
    {
        var result = new string[1] { userAnswer };
        return result;
    }

    public void SetUserAnswer(int index) => userAnswer = choosingAnswers[index].GetValue();

    public void FillAnswersWithRandom(int answer)
    {
        remainChoosingAnswers = new List<ChoosingAnswer>(choosingAnswers);
        var usedAnswers = new List<string>() { answers[0] };
        FillChoosingAnswer(answers[0]);
        for (int i = 0; i < choosingAnswers.Count - 1; i++)
        {
            var value = Randomizer.RandomizeValue(usedAnswers, answer);
            FillChoosingAnswer(value);
            usedAnswers.Add(value);
        }
    }

    public void FillAnswers(int answer)
    {
        for (int i = 0; i < choosingAnswers.Count;  i++)
            choosingAnswers[i].SetValue((i + 1).ToString());      
    }

    void FillChoosingAnswer(string value)
    {
        var choosingAnswer = remainChoosingAnswers[Random.Range(0, remainChoosingAnswers.Count)];
        choosingAnswer.SetValue(value);
        remainChoosingAnswers.Remove(choosingAnswer);
    }
}
