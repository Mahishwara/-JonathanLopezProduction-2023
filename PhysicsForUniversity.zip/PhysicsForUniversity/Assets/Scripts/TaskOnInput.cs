using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public abstract class TaskOnInput : Task
{
    [Header("InputMethod")]
    [SerializeField] public InputField[] inputFields;

    void Awake() => answers = new string[inputFields.Length];

    public override string[] ReturnUserAnswers()
    {
        var result = new string[inputFields.Length];
        for(int i = 0; i < result.Length; i++)
        {
            var answer = inputFields[i].text.ToString();
            answer = answer.ToLower().Replace(" ", "");
            result[i] = answer.Replace(".", ",");
        }
        return result;
    }
}
