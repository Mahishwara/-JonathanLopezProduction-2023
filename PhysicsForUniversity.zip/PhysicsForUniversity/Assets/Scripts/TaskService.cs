using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TaskService : MonoBehaviour
{
    [SerializeField] GameObject deviceWindow; 
    [SerializeField] AnswerChecker checker;
    [SerializeField] UIElementsActivator UIElementsActivator;
    [SerializeField] Timer timer;
    [SerializeField] TaskingConnectionsService connectionsService;
    Action actionForAnswer = () => { };
    bool actionIsActive;

    public void MakeActionForAnswer(GameObject task)
    {
        if (!actionIsActive)
        {
            var checkable = task.GetComponent<ICheckable>();
            var answerable = task.GetComponent<IAnswerable>();
            var comparableValue = checker.CheckAnswers(checkable);

            actionForAnswer = answerable.MakeActionForAnswer(comparableValue);
            if (comparableValue == 0)
            {
                AudioManager.instance.PlaySound("Success");
                UIElementsActivator.ActivateDeactivateElement(UIElementType.CorrectLabel);
                connectionsService.StartRemove();
            }
            else
            {
                UIElementsActivator.ActivateDeactivateElement(UIElementType.IncorrectLabel);
                timer.AddTime();
            }
            StartCoroutine(MakeAction());
        }
    }

    IEnumerator MakeAction()
    {
        actionIsActive = true;
        yield return new WaitForSeconds(2f);
        UIElementsActivator.ActivateDeactivateElement(UIElementType.DeviceWindow);
        actionForAnswer();
        actionIsActive = false;
    }
}
