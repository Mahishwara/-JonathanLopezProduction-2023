using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TaskSpawner : MonoBehaviour
{
    [SerializeField] TaskingConnectionsService taskingService;
    [SerializeField] Transform deviceWindow;
    GameObject activeTask;

    public void SpawnTask()
    {
        if (taskingService.IsUpdateTasking(true))
        {
            if (activeTask) Destroy(activeTask);
            taskingService.UpdateActiveTasking();
            var tasking = taskingService.GetTasking(true);
            if (tasking != null) activeTask = Instantiate(tasking.task.gameObject, deviceWindow);
        }
    }

    public void DestroyTask() => Destroy(activeTask);
}
