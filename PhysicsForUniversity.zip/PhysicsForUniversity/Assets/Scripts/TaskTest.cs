using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Random = UnityEngine.Random;
using System.Linq;

public class TaskTest : TaskOnChoosing
{
    public override void Start()
    {
        base.Start();
        answers = new string[1];
        CalculateAnswers();
        CreateCondition();
    }

    public override void CalculateAnswers()
    {
        var answer = initialData[0].Value + initialData[1].Value;
        answers[0] = answer.ToString();
        FillAnswersWithRandom((int)answer);
    }

    public override Action MakeActionForAnswer(int comparableValue)
    {
        return () => { };
    }

    public override void CreateCondition()
    {
        condition = $"{initialData[0].Value} + {initialData[1].Value}";
        SetCondition();
    }
}
