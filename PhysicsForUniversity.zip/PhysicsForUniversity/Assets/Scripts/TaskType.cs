public enum TaskType
{
    OnInput,
    OnChoosing
}
