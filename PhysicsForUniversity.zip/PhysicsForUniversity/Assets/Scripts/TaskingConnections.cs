using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class TaskingConnections
{
    public int index;
    public Task task;
    public Terminal terminal;
    public Hint hint;
    public NPC npc;
}
