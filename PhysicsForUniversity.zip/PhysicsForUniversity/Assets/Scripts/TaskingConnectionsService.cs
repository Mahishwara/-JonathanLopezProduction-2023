using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class TaskingConnectionsService : MonoBehaviour
{
    [SerializeField] List<TaskingConnections> taskings;
    [SerializeField] TaskSpawner spawner;
    [SerializeField] ButtonSystem buttonSystem;
    bool isReachedTerminal;
    public int taskingIndex;
    TaskingConnections taskingConnections;
    TaskingConnections activeTaskingConnection;

    void Awake()
    {
        foreach (var tasking in taskings)
        {
            tasking.task.index = tasking.index;
            tasking.terminal.index = tasking.index;
            tasking.hint.index = tasking.index;
            if (tasking.npc) tasking.npc.index = tasking.index;
        }
    }

    public void StartRemove() => StartCoroutine(RemoveConnection());

    IEnumerator RemoveConnection()
    {
        yield return new WaitForSeconds(2f);
        foreach (var tasking in taskings)
        {
            if (tasking.index == taskingIndex)
            {
                tasking.terminal.DeactivateTerminal();
                spawner.DestroyTask();
                taskings.Remove(tasking);
                break;
            }
        }
    }

    TaskingConnections UpdateTaskingConnection()
    {
        foreach (var tasking in taskings)
        {
            if (tasking.index == taskingIndex) return tasking;
        }
        throw new NullReferenceException();
    }

    public TaskingConnections GetTasking(bool isActivateTasking)
    {
        if (isActivateTasking) return activeTaskingConnection;
        return taskingConnections;
    }

    public void UpdateActiveTasking()
    {
        UpdateHintAvailable();
        activeTaskingConnection = UpdateTaskingConnection();
    }

    public void UpdateCurrentTasking()
    {
        if (IsUpdateTasking(false))
            taskingConnections = UpdateTaskingConnection();
    }

    public void SetTaskingIndex(int index) => taskingIndex = index;

    void UpdateHintAvailable()
    {
        if (!isReachedTerminal)
        {
            buttonSystem.isHintAvailable = true;
            isReachedTerminal = true;
        }
    }

    public bool IsUpdateTasking(bool isActiveTasking)
    {
        var tasking = isActiveTasking ? activeTaskingConnection : taskingConnections;
        return tasking == null || tasking.index != taskingIndex;
    }
}
