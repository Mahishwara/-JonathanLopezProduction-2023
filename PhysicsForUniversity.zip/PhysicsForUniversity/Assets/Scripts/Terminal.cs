using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Terminal : MonoBehaviour
{
    [SerializeField] public int index;
    [SerializeField] TaskingConnectionsService service;
    [SerializeField] UIElementsActivator UIElementsActivator;
    [SerializeField] bool isDecided;
    Transform pointButton;

    void Awake()
    {
        pointButton = transform.GetChild(0).transform;    
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (!isDecided)
        {
            if (collision.tag == "Player")
            {
                service.SetTaskingIndex(index);
                service.UpdateCurrentTasking();
                UIElementsActivator.ActivateDeactivateElement(UIElementType.DeviceButton, pointButton, index.ToString());
            }
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (!isDecided)
        {
            if (collision.tag == "Player") UIElementsActivator.ActivateDeactivateElement(UIElementType.DeviceButton, index.ToString());
        }
    }

    public void DeactivateTerminal()
    {
        isDecided = true;
        UIElementsActivator.ActivateDeactivateElement(UIElementType.DeviceButton, index.ToString());
    }
}
