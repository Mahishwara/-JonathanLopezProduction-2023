using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class Theory
{
    public int index;
    public GameObject theory;
    public bool isActivate;
}
