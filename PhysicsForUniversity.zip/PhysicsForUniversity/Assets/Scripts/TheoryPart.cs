using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TheoryPart : MonoBehaviour
{
    [SerializeField] int index;
    [SerializeField] TheoryWindow theoryWindow;

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            AudioManager.instance.PlaySound("Theory");
            theoryWindow.AddTheory(index);
            Destroy(gameObject);
        }
    }
}
