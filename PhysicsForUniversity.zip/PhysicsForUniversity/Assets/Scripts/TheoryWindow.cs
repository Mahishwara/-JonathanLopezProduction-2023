using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class TheoryWindow : MonoBehaviour
{
    [SerializeField] Transform theoryGroup;
    [SerializeField] Theory[] theories;
    Dictionary<int, Theory> dictionary;
    List<(Transform theory, int index)> activeTheories;
    bool isInitialized;

    void InitializeCollections()
    {
        isInitialized = true;
        InitializeDictionary();
        InitializeActiveTheoryList();
    }

    void InitializeActiveTheoryList() => activeTheories = new List<(Transform, int)>();

    void InitializeDictionary()
    {
        dictionary = new Dictionary<int, Theory>();
        foreach (var theory in theories) dictionary[theory.index] = theory;    
    }

    void InitializeTheory(Theory theoryConfig)
    {
        var theory = Instantiate(theoryConfig.theory, theoryGroup).transform;
        activeTheories.Add((theory, theoryConfig.index));
        if (activeTheories.Count > 1 && activeTheories.Count < theories.Length) SortTheory();
        else theory.SetSiblingIndex(theoryConfig.index);
    }

    void SortTheory()
    {
        foreach (var activeTheory in activeTheories)
            activeTheory.theory.SetSiblingIndex(activeTheory.index);
    }

    public void AddTheory(int index)
    {
        if (!isInitialized) InitializeCollections();
        dictionary[index].isActivate = true;
        InitializeTheory(dictionary[index]);
    }
}
