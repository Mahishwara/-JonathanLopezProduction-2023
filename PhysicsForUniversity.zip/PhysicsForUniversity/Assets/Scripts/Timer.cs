using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour
{
    [SerializeField] LevelSettings level;
    [SerializeField] UIElementsActivator UIElementsActivator;
    int time = 0;
    Text timeText;
    int additiveTime;
    bool isStop = true;

    void Start()
    {
        additiveTime = level.additiveTime;
        timeText = GameObject.Find("Canvas/Timer").GetComponent<Text>();
        StopStartTimer();
    }

    IEnumerator TimeCounter()
    {
        while (true)
        {
            yield return new WaitForSeconds(1);
            if (isStop) break;
            time++;
            timeText.text = time.ToString();
        }
    }

    public int ReturnTime() => time;

    public void AddTime()
    {
        AudioManager.instance.PlaySound("Fail");
        time += additiveTime;
        UIElementsActivator.ActivateDeactivateElement(UIElementType.AddTimeLabel);
        timeText.text = time.ToString();
    }

    public void StopStartTimer()
    {
        if (isStop) StartCoroutine(TimeCounter());
        isStop = !isStop;
    }    
}
