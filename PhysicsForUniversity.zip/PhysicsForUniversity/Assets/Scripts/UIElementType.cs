public enum UIElementType
{
    WinWindow,
    HintWindow,
    DeviceWindow,
    WarningWindow,
    ErrorWindow,
    CorrectLabel,
    IncorrectLabel,
    AddTimeLabel,
    DeviceButton,
    DialogCloud,
    TheoryWindow,
    PauseWindow
}
