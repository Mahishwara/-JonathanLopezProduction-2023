using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIElementsActivator : MonoBehaviour
{
    [SerializeField] UIElementsService service;
    [SerializeField] Transform globalCanvas;
    Dictionary<(UIElementType, string), GameObject> activeWindowDictionary;

    void Awake() =>
        activeWindowDictionary = new Dictionary<(UIElementType, string), GameObject>();    

    public void ActivateDeactivateElement(UIElementType windowType, float popUpTime, Transform spawnPos, string index)
    {
        var window = service.GetUIElement(windowType);
        GameObject windowObj = window.popUpWindow;
        if (activeWindowDictionary.ContainsKey((windowType, index)) && !window.isAutomatic) DeactivateElement(windowType, index);
        else
        {
            if (window.isUnique) ActivateElement(windowObj);
            else windowObj = SpawnElement(windowObj, spawnPos);

            activeWindowDictionary[(windowType, index)] = windowObj;
            if (windowType == UIElementType.DialogCloud)
            {
                var dialogCloud = windowObj.GetComponent<DialogCloud>();
                dialogCloud.SetDialog(index);
                dialogCloud.SetPoint(spawnPos);
            }
            if (window.isAutomatic) StartCoroutine(CloseWindow(windowType, index, popUpTime));
        }
    }

    void ActivateElement(GameObject window) =>
        window.SetActive(true);

    GameObject SpawnElement(GameObject window, Transform spawnPos)
    {
        var obj = Instantiate(window, spawnPos.position, Quaternion.identity);
        obj.transform.SetParent(globalCanvas);
        return obj;
    }

    void DeactivateElement(UIElementType windowType, string index)
    {
        var window = activeWindowDictionary[(windowType, index)];
        if (service.GetUIElement(windowType).isUnique) window.SetActive(false);
        else Destroy(window);
        activeWindowDictionary.Remove((windowType, index));
    }

    IEnumerator CloseWindow(UIElementType type, string index, float time)
    {
        yield return new WaitForSeconds(time);
        if (activeWindowDictionary.ContainsKey((type, index))) DeactivateElement(type, index);
    }

    public void ActivateDeactivateElement(UIElementType windowType, Transform spawnPos, string index) =>
        ActivateDeactivateElement(windowType, service.GetUIElement(windowType).popUpTime, spawnPos, index);

    public void ActivateDeactivateElement(UIElementType windowType, Transform spawnPos) =>
        ActivateDeactivateElement(windowType, spawnPos, "");

    public void ActivateDeactivateElement(UIElementType windowType, string index) =>
        ActivateDeactivateElement(windowType, null, index);

    public void ActivateDeactivateElement(UIElementType windowType) =>
        ActivateDeactivateElement(windowType, "");
}
