using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class UIElementConfig
{
    public UIElementType type;
    public GameObject popUpWindow;
    public float popUpTime;
    public bool isAutomatic;
    public bool isUnique;
}
