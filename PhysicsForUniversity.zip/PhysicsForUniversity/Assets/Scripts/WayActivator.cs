using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WayActivator : MonoBehaviour
{
    PlayerMovement player;
    WayService wayService;

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerMovement>();
        wayService = GetComponent<WayService>();
    }

    public void ActivateWay(string index)
    {
        var directorConfig = wayService.GetDirector(index);
        if (directorConfig.playerTarget) player.StartMoveToTarget(directorConfig.playerTarget, (float)directorConfig.director.duration);
        directorConfig.ActivateWay();
    }
}
