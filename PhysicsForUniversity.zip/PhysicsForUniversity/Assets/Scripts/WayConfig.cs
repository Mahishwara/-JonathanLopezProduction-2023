using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Playables;

[Serializable]
public class WayConfig
{
    public string index;
    public PlayableDirector director;
    public Transform playerTarget;
    public GameObject way;
    public bool isAnimation;

    public void ActivateWay()
    {
        if (isAnimation) director.Play();
        else way.SetActive(!way.gameObject.activeSelf);
    }
}
