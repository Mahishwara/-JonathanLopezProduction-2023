using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Playables;

public class WayService : MonoBehaviour
{
    [SerializeField] WayConfig[] directorConfigs;
    Dictionary<string, WayConfig> directorsDictionary;

    void Awake()
    {
        directorsDictionary = new Dictionary<string, WayConfig>();
        foreach (var directorConfig in directorConfigs) directorsDictionary[directorConfig.index] = directorConfig;
    }

    public WayConfig GetDirector(string index) => directorsDictionary[index];
}
