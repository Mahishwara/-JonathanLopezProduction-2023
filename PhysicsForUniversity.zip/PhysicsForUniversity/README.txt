Ссылка на apk файл игры: 
https://drive.google.com/file/d/1QoYgFTOY38_t6rYwDPflmO9P7qj66p_x/view